const name='Mike';
const age=25;
const add=(a,b)=>{
    return a+b;
}
module.exports={
    name,
    age,
    add
}